import { model, Schema } from "mongoose";
import { ACCOUNT_STATUS, ACCOUNT_STATUS_VALUES, USER_ROLE_VALUES } from "./user.constant";
import { IUser } from "./user.interface";
import { hashedPassword } from "../../helpers/PasswordHelper";

const userSchema = new Schema<IUser>(
  {
    fullName: {
      type: String,
      required: [true, "Full name is required"],
      trim: true,
    },
    email: {
      type: String,
      required: [true, "Email is required"],
      unique: true,
      lowercase: true,
      trim: true,
    },
    phone: {
      type: String,
      required: [true, "Phone number is required"],
      unique: true,
      trim: true,
    },
    password: {
      type: String,
      required: [true, "Password is required"],
      select: false,
    },
    role: {
      type: String,
      enum: USER_ROLE_VALUES,
    },
    profileImg: {
      type: String,
      default: "",
    },
    isEmailVerified: {
      type: Boolean,
      default: false,
    },
    emailVerifiedAt: {
      type: Date,
      default: null,
    },
    status: {
      type: String,
      enum: ACCOUNT_STATUS_VALUES,
      default: ACCOUNT_STATUS.PENDING,
    },
    googleId: {
      type: String,
      default: null,
    },
    appleId: {
      type: String,
      default: null,
    },
    blockedAt: {
      type: Date,
      default: null,
    },
    passwordChangedAt: {
      type: Date,
      default: null,
    },
    lastLoginAt: {
      type: Date,
      default: null,
    },
    tokenVersion: {
      type: Number,
      default: 0,
    },
  },
  {
    timestamps: true,
    versionKey: false,
  },
);


// Hash password before saving
userSchema.pre("save", async function (this: any) {
  // `this` refers to the document being saved
  if (!this.isModified("password")) return;
  this.password = await hashedPassword(this.password);
});

const UserModel = model<IUser>("User", userSchema);
export default UserModel;
